﻿# Student-Information-system-with-php
localhost network....2 sites staff side and admin side
Installation Steps(Configuration)

Database Configuration

Open phpmyadmin

Create Database onlinecourse

Import database onlinecourse.sql 

Open Your browser put inside browser 

Login Details
To Login as admin put inside browser 

Login Details for admin : admin/Test@123

To Login as Student put inside browser 

Login Details for Staff: 10806121/123

