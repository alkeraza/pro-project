<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2020 Online Student Information System | By : <a href=""_blank">Shivam</a>
                </div>

            </div>
        </div>
    </footer>