<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                             <li><a href="pincode-verification.php">Enroll for A Language Course </a></li>
                             <li><a href="enroll-history.php">Enroll History  </a></li>
							 <li><a href="marks.php">student Marks  </a></li>
                              <li><a href="my-profile.php">Teacher Profile</a></li>
							  <li><a href="course.php">Enroll Student</a></li>
                               <li><a href="change-password.php">Change Password</a></li>
                            <li><a href="logout.php">Logout</a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>